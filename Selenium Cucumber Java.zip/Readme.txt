How to Run

1. Download zip
2. Extract the zip under C:\Users\user\eclipse-workspace
3. Open Eclipse
4. Go to Verint -> src\test\resource -> Feature
5. Open TestWeb.feature
6. Run as Cucumber Feature