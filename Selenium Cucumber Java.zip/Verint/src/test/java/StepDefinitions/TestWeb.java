package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.*;


public class TestWeb {

	WebDriver driver = null;
	
	@Given("browser is open")
	public void browser_is_open() {
		System.setProperty("webdriver.chrome.driver","C:/Users/user/eclipse-workspace/Verint/src/test/resources/driver/chromedriver.exe");
		
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}
	
	@And("user on verint webpage")
	public void user_on_verint_webpagen() {
		driver.manage().timeouts().implicitlyWait(20,TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(20,TimeUnit.SECONDS);
		driver.navigate().to("https://www.verint.com");
	}

	@When("user enter text")
	public void user_enter_text() {
		driver.findElement(By.id("nav-toggle")).click();
		driver.findElement(By.id("downshift-0-input")).sendKeys("customer solution");
	}

	@And("hits enter")
	public void hits_enter() {
		driver.findElement(By.id("downshift-0-input")).sendKeys(Keys.ENTER);
	}

	@Then("check result")
	public void check_result() {
		driver.getPageSource().contains("customer solution");
	}
}
